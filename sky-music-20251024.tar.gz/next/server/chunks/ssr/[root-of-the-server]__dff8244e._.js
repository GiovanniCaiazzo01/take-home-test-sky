module.exports = [
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[project]/src/UI/components/Text/Text.styled.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StyledBaseText",
    ()=>StyledBaseText,
    "StyledBodyLG",
    ()=>StyledBodyLG,
    "StyledBodyMD",
    ()=>StyledBodyMD,
    "StyledBodySM",
    ()=>StyledBodySM,
    "StyledCaption",
    ()=>StyledCaption,
    "StyledDisplayLG",
    ()=>StyledDisplayLG,
    "StyledDisplayMD",
    ()=>StyledDisplayMD,
    "StyledDisplaySM",
    ()=>StyledDisplaySM,
    "StyledDisplayXL",
    ()=>StyledDisplayXL,
    "StyledLabel",
    ()=>StyledLabel,
    "StyledTitleLG",
    ()=>StyledTitleLG,
    "StyledTitleMD",
    ()=>StyledTitleMD,
    "StyledTitleSM",
    ()=>StyledTitleSM
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.esm.js [app-ssr] (ecmascript)");
"use client";
;
const StyledBaseText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].div.attrs({
    className: "font-sans m-0"
})``;
const StyledDisplayXL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[4.5rem] leading-[1.1] tracking-[-0.03em] font-bold
    md:text-[3rem]
  `
})``;
const StyledDisplayLG = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[3.75rem] leading-[1.15] tracking-[-0.025em] font-bold
    md:text-[2.5rem]
  `
})``;
const StyledDisplayMD = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[3rem] leading-[1.2] tracking-[-0.02em] font-semibold
    md:text-[2rem]
  `
})``;
const StyledDisplaySM = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[2.25rem] leading-[1.25] tracking-[-0.015em] font-semibold
    md:text-[1.75rem]
  `
})``;
const StyledTitleLG = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[1.875rem] leading-[1.3] tracking-[-0.01em] font-semibold
    md:text-[1.5rem]
  `
})``;
const StyledTitleMD = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[1.5rem] leading-[1.35] font-semibold
    md:text-[1.25rem]
  `
})``;
const StyledTitleSM = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[1.25rem] leading-[1.4] font-semibold
  `
})``;
const StyledBodyLG = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[1.125rem] leading-[1.6] font-normal
  `
})``;
const StyledBodyMD = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[1rem] leading-[1.6] font-normal
  `
})``;
const StyledBodySM = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[0.875rem] leading-[1.5] font-normal
  `
})``;
const StyledCaption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[0.875rem] leading-[1.4] tracking-[0.02em] font-normal
  `
})``;
const StyledLabel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(StyledBaseText).attrs({
    className: `
    text-[0.875rem] leading-[1.4] tracking-[0.01em] font-medium
  `
})``;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__dff8244e._.js.map