globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/f8d6268974047388.js",
      "static/chunks/turbopack-d14bb264a956d191.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/f8d6268974047388.js",
      "static/chunks/turbopack-0cb800c08b23235f.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/409daa79903bdca4.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/3e0f93b37bf948e9.js",
    "static/chunks/111c2078ff56494a.js",
    "static/chunks/8de370c3cbabf345.js",
    "static/chunks/turbopack-213bf19ea13b3acd.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];