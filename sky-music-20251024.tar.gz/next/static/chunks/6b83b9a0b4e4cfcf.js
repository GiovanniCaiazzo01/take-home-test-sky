__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/f8d6268974047388.js",
  "static/chunks/turbopack-d14bb264a956d191.js"
])
