(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__df9674ef._.css",
  "static/chunks/node_modules_12149491._.js",
  "static/chunks/src_1ef664b7._.js"
],
    source: "dynamic"
});
