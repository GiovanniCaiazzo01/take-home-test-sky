(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_922d60df._.js",
  "static/chunks/src_UI_components_Text_Text_styled_tsx_8fac2fa2._.js"
],
    source: "dynamic"
});
