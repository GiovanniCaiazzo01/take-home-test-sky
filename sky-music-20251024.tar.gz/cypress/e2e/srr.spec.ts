describe('SSR Top 100', () => {
  it('renders album cards in the HTML (no JS execution)', () => {
    cy.request('/album/top-100').its('body').then((html) => {
      expect(html).to.contain('data-testid="album-list"');
      expect(html).to.contain('data-testid="album-card"'); 
    });
  });
});
