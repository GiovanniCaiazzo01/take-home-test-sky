describe('Accessibility', () => {
  it('has no obvious a11y violations on Top 100', () => {
    cy.visit('/album/top-100');
    cy.checkA11yPage();
  });
});
