describe('Favorites persist', () => {
  beforeEach(() => {
    cy.intercept('GET', 'https://itunes.apple.com/us/rss/topalbums/limit=100/json',
      { fixture: 'itunes-top100.json' }
    ).as('itunes');
  });

  it('toggles favorite and persists after reload', () => {
    cy.visit('/album/top-100');
    cy.wait('@itunes');

    cy.findAllByTestId('album-card').first().as('card');
    cy.get('@card').findByTestId('favorite-toggle').click();

    // verifica stato "pressed" o classe attiva
    cy.get('@card').findByTestId('favorite-toggle')
      .should('have.attr', 'aria-pressed', 'true');

    cy.reload();
    cy.wait('@itunes');

    // ancora preferito dopo reload
    cy.findAllByTestId('album-card').first()
      .findByTestId('favorite-toggle')
      .should('have.attr', 'aria-pressed', 'true');
  });
});
