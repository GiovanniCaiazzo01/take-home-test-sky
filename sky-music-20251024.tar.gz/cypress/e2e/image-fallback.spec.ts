describe('Image fallback', () => {
  it('shows placeholder on image error', () => {
    cy.intercept('GET', 'https://is1-ssl.mzstatic.com/*', { statusCode: 404 }).as('img404');
    cy.visit('/album/top-100');
    cy.findAllByRole('img').first().should('be.visible');
    cy.findAllByRole('img').first().should('have.attr', 'src').and('match', /file\.svg|_next\/image/);
  });
