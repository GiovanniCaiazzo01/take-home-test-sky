describe('Top 100 page', () => {
  beforeEach(() => {
    cy.intercept('GET', 'https://itunes.apple.com/us/rss/topalbums/limit=100/json',
      { fixture: 'itunes-top100.json' }
    ).as('itunes');
  });

  it('shows 100 albums and basic UI', () => {
    cy.visit('/album/top-100');
    cy.wait('@itunes');
    cy.findByTestId('album-list').within(() => {
      cy.findAllByTestId('album-card').should('have.length', 100);
    });
    cy.checkA11yPage();
  });
});
