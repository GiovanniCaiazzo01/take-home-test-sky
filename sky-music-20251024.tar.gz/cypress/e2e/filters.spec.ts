describe('Filters & URL params', () => {
  beforeEach(() => {
    cy.intercept('GET', 'https://itunes.apple.com/us/rss/topalbums/limit=100/json',
      { fixture: 'itunes-top100.json' }
    ).as('itunes');
  });

  it('updates URL when typing in search and filters list', () => {
    cy.visit('/album/top-100');
    cy.wait('@itunes');

    cy.findByTestId('filter-search').type('beatles');
    cy.url().should('include', 'search=beatles');

    cy.findAllByTestId('album-card').its('length').should('be.lt', 100);
  });

  it('applies genre filter and reflects in URL', () => {
    cy.visit('/album/top-100');
    cy.wait('@itunes');

    cy.findByTestId('filter-genre').click(); // select open
    cy.findByRole('option', { name: /rock/i }).click();
    cy.url().should('include', 'genre=');
  });
});
