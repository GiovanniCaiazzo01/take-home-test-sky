type AuthorLabel = {
  label: string;
};

export type Author = {
  name: AuthorLabel;
  uri: AuthorLabel;
};
