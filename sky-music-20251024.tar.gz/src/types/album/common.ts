export type Label = {
  label: string;
};
