export type ButtonSize = "sm" | "md" | "lg";
