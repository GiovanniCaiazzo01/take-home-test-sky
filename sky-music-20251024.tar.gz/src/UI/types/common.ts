export type ComponentVariant =
  | "success"
  | "warning"
  | "error"
  | "info"
  | "neutral";
