import { Text } from "@THTS/UI/components/Text";

export default function Home() {
  return <Text variant="title-lg">Test Title</Text>;
}
